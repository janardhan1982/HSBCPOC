package restapirun;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(
		
		features="src/test/resources/features",
		glue="stepdefinitions",
		dryRun=false,
		monochrome=true,
		plugin = {"pretty",
				"html:target/html/",
				"json:target/json/file.json"
				
		}
		

		)

public class RunnerTest{
	
}

