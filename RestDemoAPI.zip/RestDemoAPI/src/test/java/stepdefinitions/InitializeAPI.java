package stepdefinitions;

import cucumber.api.Scenario;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class InitializeAPI {

	protected RequestSpecification req_spec=null;
    protected Response resp=null;
    protected Scenario scn=null;
    
}
